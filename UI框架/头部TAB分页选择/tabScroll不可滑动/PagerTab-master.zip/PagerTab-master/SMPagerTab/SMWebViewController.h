//
//  SMWebViewController.h
//  SMPagerTab
//
//  Created by ming on 15/7/4.
//  Copyright (c) 2015年 starming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SMWebViewController : UIViewController

@property (nonatomic, strong) NSString* webUrlString;

@end
