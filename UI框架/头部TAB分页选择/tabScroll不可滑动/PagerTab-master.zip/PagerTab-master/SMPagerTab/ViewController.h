//
//  ViewController.h
//  SMPagerTab
//
//  Created by ming on 15/7/4.
//  Copyright (c) 2015年 starming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SMPagerTabView.h"

@interface ViewController : UIViewController<SMPagerTabViewDelegate>


@end

