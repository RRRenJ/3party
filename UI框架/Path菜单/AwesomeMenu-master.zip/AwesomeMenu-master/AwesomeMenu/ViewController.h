//
//  ViewController.h
//  AwesomeMenu
//
//  Created by tong on 16/4/11.
//
//

#import <UIKit/UIKit.h>
#import "AwesomeMenu/AwesomeMenu.h"

@interface ViewController : UIViewController

@end
