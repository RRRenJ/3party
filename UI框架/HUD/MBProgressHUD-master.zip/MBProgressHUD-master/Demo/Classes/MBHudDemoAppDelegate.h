//
//  MBHudDemoAppDelegate.h
//  HudDemo
//
//  Created by Matej Bukovinski on 2.4.09.
//  Copyright bukovinski.com 2009-2015. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MBHudDemoAppDelegate : NSObject <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
